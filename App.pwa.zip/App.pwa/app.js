document.getElementById('get-location').addEventListener('click', () => {
    if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition((position) => {
            const { latitude, longitude } = position.coords;
            document.getElementById('location-output').textContent = `Latitude: ${latitude}, Longitude: ${longitude}`;

            const map = L.map('map').setView([latitude, longitude], 13);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);
            L.marker([latitude, longitude]).addTo(map)
                .bindPopup('Você está aqui.')
                .openPopup();
        }, (error) => {
            document.getElementById('location-output').textContent = 'Erro ao obter a localização.';
        });
    } else {
        alert('Geolocalização não é suportada pelo navegador.');
    }
});

document.getElementById('open-camera').addEventListener('click', () => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
            const video = document.getElementById('camera-output');
            video.srcObject = stream;
        }).catch((error) => {
            alert('Erro ao acessar a câmera: ' + error);
        });
    } else {
        alert('Câmera não é suportada pelo navegador.');
    }
});

document.getElementById('record-audio').addEventListener('click', () => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
            const audio = document.getElementById('audio-output');
            audio.srcObject = stream;
        }).catch((error) => {
            alert('Erro ao acessar o microfone: ' + error);
        });
    } else {
        alert('Microfone não é suportado pelo navegador.');
    }
});

document.getElementById('get-orientation').addEventListener('click', () => {
    if ('DeviceOrientationEvent' in window) {
        window.addEventListener('deviceorientation', (event) => {
            const { alpha, beta, gamma } = event;
            document.getElementById('orientation-output').textContent = `Orientação: alpha=${alpha}, beta=${beta}, gamma=${gamma}`;
        });
    } else {
        alert('Sensores de orientação não são suportados pelo navegador.');
    }
});

if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js')
        .then(() => console.log('Service Worker registrado com sucesso.'))
        .catch((error) => console.log('Erro ao registrar o Service Worker:', error));
}